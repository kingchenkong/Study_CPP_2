rm -rf ./build/*
cd ./build
cmake ../
make all